require({cache:{
'url:epi-ecf-ui/component/templates/PricingOverview.html':"﻿<div>\r\n    <div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"epi-cms/contentediting/StandardToolbar\" class=\"epi-viewHeaderContainer epi-localToolbar\"></div>\r\n    <div data-dojo-type='epi-ecf-ui/widget/PricingOverview' data-dojo-attach-point='pricingOverview'></div>\r\n</div>"}});
﻿define("epi-ecf-ui/component/PricingOverview", [
    "dojo/_base/declare",
    "dojo/dom-geometry",
// dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
// resources
    "dojo/text!./templates/PricingOverview.html",
    "epi/i18n!epi/cms/nls/commerce.components.pricingoverview",
// Widgets in the template
    "epi-cms/contentediting/StandardToolbar",
    "../widget/PricingOverview"
], function (
    declare,
    domGeometry,
// dijit
    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
// resources
    template,
    resources
) {
    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin], {
        // summary:
        //      This is the initializer of Price Preview.
        resources: resources,

        templateString: template,

        updateView: function (data, context) {
            // summary:
            //		Updates the view, to reflect data changes.(when opening this view second time)
            // tags:
            //		protected

            this.toolbar.update({
                currentContext: context,
                viewConfigurations: {
                    availableViews: data.availableViews,
                    viewName: data.viewName
                }
            });
            this.set("value", context);
            // display top notification bar
            this.pricingOverview.showNotification();
        },

        _setValueAttr: function (value) {
            this.pricingOverview.set("value", value);
        },

        layout: function () {
            // summary:
            //		Layout the children widgets.
            // tags:
            //		protected

            var toolbarSize = domGeometry.getMarginBox(this.toolbar.domNode);

            // Set the size of the pricing overview to be the content height minus the toolbar height.
            this.pricingOverview.resize({
                h: this._contentBox.h - toolbarSize.h,
                w: this._contentBox.w
            });
        }

    });

});
