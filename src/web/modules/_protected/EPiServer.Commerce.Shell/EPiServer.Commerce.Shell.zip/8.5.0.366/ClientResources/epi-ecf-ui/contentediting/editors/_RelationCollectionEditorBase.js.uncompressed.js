﻿define("epi-ecf-ui/contentediting/editors/_RelationCollectionEditorBase", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Deferred",
    "dojo/when",
    "dojo/aspect",
    "dojo/dom-construct",
    "dojo/dom-class",

    // dgrid
    "dgrid/Keyboard",
    "dgrid/OnDemandGrid",
    "dgrid/Selection",
    "dgrid/extensions/ColumnResizer",
    "dgrid/extensions/ColumnReorder",

    // EPi Framework
    "epi/dependency",
    "epi/shell/dgrid/Formatter",

    // epi cms
    "epi-cms/contentediting/editors/CollectionEditor",
    "epi-cms/contentediting/editors/model/CollectionEditorModel",
    "epi-cms/dgrid/DnD",
    "epi-cms/dgrid/WithContextMenu",
    "epi-cms/widget/ContentSelectorDialog",

    // commerce
    "./RelationCollectionGridAssembler",
    "../ModelSupport",
     "./LinkEditorDndMixin",
     "../../dgrid/_ClickablePathColumnMixin"
],
function (
    //dojo
    declare,
    lang,
    Deferred,
    when,
    aspect,
    domConstruct,
    domClass,

    // dgrid
    Keyboard,
    OnDemandGrid,
    Selection,
    ColumnResizer,
    ColumnReorder,

    // EPi Framework
    dependency,
    Formatter,

    // epi cms
    CollectionEditor,
    CollectionEditorModel,
    DnD,
    WithContextMenu,
    ContentSelectorDialog,

    // commerce
    RelationCollectionGridAssembler,
    ModelSupport,
    LinkEditorDndMixin,
    _ClickablePathColumnMixin
) {
    return declare([CollectionEditor, LinkEditorDndMixin], {
        // module:
        //      epi-ecf-ui/contentediting/editors/RelationCollectionEditEditor
        // summary:
        //      Represents the Read-only editor widget for product's price overview list.

        baseClass: "epi-relationCollectionEditor",

        /*jshint multistr: true */
        templateString: '<div>\
                            <div data-dojo-attach-point="commandTargetNode"></div>\
                            <div data-dojo-attach-point="overlayDnd">\
                                <div class="epi-associationCollectionEditor" data-dojo-attach-point="gridNode"></div>\
                            <div>\
                        </div>',

        resources: null,

        gridOverlayClass: "epi-grid-dnd-overlay",

        itemType: "EPiServer.Commerce.Shell.Rest.Models.RelationModel",

        itemEditorTypes: null,

        storeKey: "epi.commerce.relation",

        itemEditorType: ContentSelectorDialog,

        commands: CollectionEditorModel.commandMask.remove,

        gridAssemblerType: RelationCollectionGridAssembler,

        gridType: declare([OnDemandGrid, Formatter, Selection, Keyboard, DnD, ColumnResizer, ColumnReorder, WithContextMenu, _ClickablePathColumnMixin]),

        postMixInProperties: function() {
            // summary:
            //      init _store and gridSettings
            // tags:
            //      public override
            this.inherited(arguments);

            var registry = dependency.resolve("epi.storeregistry");
            this._store = this._store || registry.get(this.storeKey);

            if (!this.roots) {
                var contentRepositoryDescriptors = dependency.resolve("epi.cms.contentRepositoryDescriptors");
                var settings = contentRepositoryDescriptors.catalog;
                this.roots = settings.roots;
            }

            this.gridSettings = lang.mixin(this.gridSettings || {}, {
                useDeleteWithConfirmation: true,
                dndSourceTypes: [ModelSupport.linkTypeIdentifier.relation],
                deleteConfirmationTitle: this.resources.deleteconfirmation.title,
                deleteConfirmationMessage: this.resources.deleteconfirmation.description
            });
        },

        _dndNodeCreator: function(/*Object*/item, /*Object*/hint) {
            var dndTypes = this.allowedDndTypes,
                node = domConstruct.create("div").appendChild(document.createTextNode(item.name));

            return {
                "node": node,
                "type": dndTypes,
                "data": item
            };
        },

        onExecuteDialog: function () {
            var contentLink = this._itemEditor.get("value");
            this.model.addItem(this._createItem(contentLink));
        },

        _renderNoDataMessage: function () {
            this.grid.set("noDataMessage", this.resources.nodatamessage);
            this.inherited(arguments);
        },


        _getDialogTitleText: function () {
            return this.resources.addlabel;
        },

        _createItemEditor: function () {
            return new this.itemEditorType({
                canSelectOwnerContent: false,
                showButtons: false,
                roots: this.roots,
                allowedTypes: this.itemEditorTypes,
                showAllLanguages: false
            });
        },

        _dndGetItemData: function (item) {
            return when(item.data, lang.hitch(this, function (data) {
                if (data) {
                    return this._createItem(data.contentLink, data.name);
                }
            }));
        },

        _createItem: function (targetLink, name) {
            return {
                name: name || targetLink,
                sortOrder: 0,
                source: this.model.get("data"),
                target: targetLink,
                type: this.relationType
            };
        },

        _setupDnD: function () {
            // summary:
            //      Set up the dnd on the grid.
            // tags:
            //      private
            this.inherited(arguments);
            this.setupDndActions(this.grid.dndSource, "checkAcceptance");

            this.own(aspect.after(this.grid.dndSource, "onDndStart", lang.hitch(this, function (source, nodes, copy) {
                var dndSource = this.grid.dndSource,
                                    accepted = dndSource.accept && dndSource.checkAcceptance(source, nodes);

                domClass[accepted ? "add" : "remove"](this.overlayDnd, this.gridOverlayClass);
            }), true));
        }
    });
});
