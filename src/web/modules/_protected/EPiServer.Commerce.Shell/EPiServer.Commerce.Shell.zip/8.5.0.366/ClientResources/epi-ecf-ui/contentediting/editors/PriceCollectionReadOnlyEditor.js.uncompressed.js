﻿define("epi-ecf-ui/contentediting/editors/PriceCollectionReadOnlyEditor", [
    // dojo
    "dojo/_base/declare",

    // epi commerce
    "./ReadOnlyCollectionEditor",
    "../viewmodel/PriceCollectionReadOnlyEditorModel",
        
    // Resources
    "epi/i18n!epi/cms/nls/commerce.components.catalogs.commands"
],
function (
    //dojo
    declare,

    // epi commerce
    ReadOnlyCollectionEditor,
    PriceCollectionReadOnlyEditorModel,
    
    res
) {
    return declare([ReadOnlyCollectionEditor], {
        // module: 
        //      epi-ecf-ui/contentediting/editors/PriceCollectionReadOnlyEditor
        // summary:
        //      Represents the Read-only editor widget for product's price list.

        iconClass: "epi-iconPricing",

        modelType: PriceCollectionReadOnlyEditorModel,
        
        changeToView: "pricingview",
        
        buttonLabel: res.previewprice
    });
});