require({cache:{
'url:epi-ecf-ui/widget/viewmodel/templates/CampaignNameColumn.html':"﻿<div>\n    <h1>${name}</h1>\n    <h2>${group}</h2>\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/CampaignOrdersColumn.html':"﻿<h1>${nrOfOrders}</h1>\n<h2>${text}</h2>",
'url:epi-ecf-ui/widget/viewmodel/templates/CampaignStatusColumn.html':"﻿<h1>${statusLabel}</h1>\n<h2>${fromDate} - ${toDate}</h2>",
'url:epi-ecf-ui/widget/viewmodel/templates/PromotionNameColumn.html':"﻿<h3>${name}</h3>\n<span class=\"dijitInline dijitReset dijitIcon epi-objectIcon ${iconClass}\"></span> <span class=\"epi-secondaryText\">${group}</span>",
'url:epi-ecf-ui/widget/viewmodel/templates/PromotionOrdersColumn.html':"﻿<h2>\n    <h3>${nrOfOrders}</h3>\n    <span class=\"epi-secondaryText\">${text}</span>\n</h2>",
'url:epi-ecf-ui/widget/viewmodel/templates/PromotionStatusColumn.html':"﻿<div class=\"epi-grid-column--centered\">\n    ${text} ${date}\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/RedeemedValueColumn.html':"﻿<h1>${redeemedValueAmount}</h1>\n<h2>${redeemedValue}</h2>"}});
﻿define("epi-ecf-ui/widget/viewmodel/CampaignItemListModel", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-class",
    "dojo/dom-construct",
    "dojo/string",

//dgrid
    "dgrid/tree",

// epi
    "epi/datetime",
    "epi/shell/dgrid/util/misc",
    "epi/shell/TypeDescriptorManager",

// epi-ecf-ui
    "../../MarketingUtils",

// resources
    "epi/i18n!epi/nls/commerce.widget.campaignitemlist",
    "dojo/text!./templates/CampaignNameColumn.html",
    "dojo/text!./templates/CampaignOrdersColumn.html",
    "dojo/text!./templates/CampaignStatusColumn.html",
    "dojo/text!./templates/PromotionNameColumn.html",
    "dojo/text!./templates/PromotionOrdersColumn.html",
    "dojo/text!./templates/PromotionStatusColumn.html",
    "dojo/text!./templates/RedeemedValueColumn.html"
],

function (
// dojo
    declare,
    lang,
    domClass,
    domConstruct,
    dojoString,

//dgrid
    tree,

// epi
    epiDate,
    shellMisc,
    TypeDescriptorManager,

// epi-ecf-ui
    MarketingUtils,

// resources
    resources,
    campaignNameColumnTemplate,
    campaignOrdersColumnTemplate,
    campaignStatusColumnTemplate,
    promotionNameColumnTemplate,
    promotionOrdersColumnTemplate,
    promotionStatusColumnTemplate,
    redeemedValueColumnTemplate
) {

    return declare([], {
        // summary:
        //      Model for CampaignItemList.
        // tags:
        //      public

        createGridColumns: function () {
            var columns = {
                expando: tree({
                    label: "",
                    sortable: false,
                    shouldExpand: function() { return true; },
                    renderExpando: function(level, hasChildren, expanded, object){
                        // summary:
                        //      We override the default expando rendering to get rid of the
                        //      default indentation.

                        var node = domConstruct.create("div");
                        //"dgrid-expando-icon" is needed for click events
                        domClass.add(node, "dgrid-expando-icon");
                        node.innerHTML = "&nbsp;";
                        return node;
                    }
                }),
                name: {
                    className: "epi-grid--40",
                    get: function (campaignItem) {
                        return { name: campaignItem.name, group: campaignItem.group, typeIdentifier: campaignItem.typeIdentifier, itemType: campaignItem.itemType };
                    },
                    formatter: lang.hitch(this, this._getNameHtml)
                },
                status: {
                    className: "epi-grid-column--centered",
                    get: lang.hitch(this, this._getStatusModel),
                    formatter: lang.hitch(this, this._getStatusHtml)
                },
                redeemed: {
                    className: "epi-grid--15",
                    get: function (campaignItem) {
                        return { itemType: campaignItem.itemType, amount: campaignItem.redeemed };
                    },
                    formatter: lang.hitch(this, this._getOrdersHtml),
                    renderCell: lang.hitch(this, function (item, value, node, options) {
                        domClass.add(node, "epi-grid-column--centered");
                        node.innerHTML = this._getOrdersHtml(value);
                    })
                },
                redeemedValue: {
                    className: "epi-grid--15",
                    get: function (campaignItem) {
                        return { itemType: campaignItem.itemType, revenue: campaignItem.redeemedValue };
                    },
                    formatter: lang.hitch(this, this._getRevenueValueHtml),
                    renderCell: lang.hitch(this, function (item, value, node, options) {
                        domClass.add(node, "epi-grid-column--centered");
                        node.innerHTML = this._getRevenueValueHtml(value);
                    })
                }
            };

            return columns;
        },

        getItemClass: function(campaignItem) {
            switch (campaignItem.itemType) {
                case MarketingUtils.type.campaign:
                    /* falls through */
                default:
                    return "epi-card-grid__heading";
                case MarketingUtils.type.promotion:
                    return "epi-card-grid__content";
            }
        },

        getItemStatusClass: function(campaignItem) {
            var itemType = campaignItem.itemType;
            var itemStatus = campaignItem.status;

            if (itemType === MarketingUtils.type.campaign) {
                var campaignClass = "epi-card-grid__heading--";
                switch (itemStatus) {
                    case MarketingUtils.status.pending:
                        return campaignClass + "pending";
                    case MarketingUtils.status.active:
                        return campaignClass + "active";
                    case MarketingUtils.status.expired:
                        return campaignClass + "expired";
                    default:
                        return campaignClass + "inactive";
                }
            } else if (itemType === MarketingUtils.type.promotion) {
                var promotionClass = "epi-card-grid__content--";

                if (itemStatus === MarketingUtils.status.active) {
                    return promotionClass + "active";
                }
                if (itemStatus === MarketingUtils.status.pending) {
                    return promotionClass + "pending";
                }
                return promotionClass + "inactive";
            }
        },

        _getStatusHtml: function (statusColumnModel) {

            if (statusColumnModel.itemType === MarketingUtils.type.campaign) {
                return dojoString.substitute(campaignStatusColumnTemplate, {
                    statusLabel: resources.status[statusColumnModel.statusLabelKey],
                    fromDate: epiDate.toUserFriendlyString(statusColumnModel.startDate),
                    toDate: epiDate.toUserFriendlyString(statusColumnModel.endDate)
                });
            }

            var promotionStatus = statusColumnModel.status;
            var campaignStatus = statusColumnModel.campaignStatus;

            if (statusColumnModel.followsCampaignSchedule || campaignStatus === MarketingUtils.status.expired || campaignStatus === MarketingUtils.status.inactive) {
                return "";
            }

            if (promotionStatus === MarketingUtils.status.active) {
                return dojoString.substitute(promotionStatusColumnTemplate, {
                    text: epiDate.toUserFriendlyString(statusColumnModel.startDate) + " - ",
                    date: epiDate.toUserFriendlyString(statusColumnModel.endDate)
                });
            }

            if (promotionStatus === MarketingUtils.status.inactive) {
                return resources.status.inactive;
            }

            return dojoString.substitute(promotionStatusColumnTemplate, {
                date: epiDate.toUserFriendlyString(this._getDate(statusColumnModel)),
                text: this._getDateText(statusColumnModel)
            });
        },

        _getStatusModel: function(campaignItem) {
            var startDate = new Date(campaignItem.startDate);
            var endDate = new Date(campaignItem.endDate);

            return {
                status: campaignItem.status,
                statusLabelKey: this._getStatus(campaignItem),
                startDate: startDate,
                endDate: endDate,
                itemType: campaignItem.itemType,
                campaignStatus: campaignItem.campaignStatus,
                followsCampaignSchedule: campaignItem.followsCampaignSchedule
            };
        },

        _getStatus: function (campaignItem) {
            switch (campaignItem.status) {
                case MarketingUtils.status.pending:
                    return "pending";
                case MarketingUtils.status.active:
                    return "active";
                case MarketingUtils.status.suspended:
                    return "suspended";
                case MarketingUtils.status.expired:
                    return "expired";
                case MarketingUtils.status.deleted:
                    return "deleted";
                default:
                    return "inactive";
                }
        },

        _getDate: function (statusColumnModel) {

            if (statusColumnModel.startDate > new Date()) {
                return statusColumnModel.startDate;
            }

            return statusColumnModel.endDate;
        },

        _getDateText: function (statusColumnModel) {
            var startDate = statusColumnModel.startDate,
                endDate = statusColumnModel.endDate,
                now = new Date();

            if (startDate < now && endDate > now) { // Currently active
                return resources.datetext.active;
            }

            if (startDate > now) { // Pending
                return resources.datetext.pending;
            }

            return resources.datetext.expired; // Expired
        },

        _getOrdersHtml: function (nrOfOrdersModel) {
            var text = resources.orders;
            var template = promotionOrdersColumnTemplate;

            if (nrOfOrdersModel.itemType === MarketingUtils.type.campaign) {
                text = resources.totalorders;
                template = campaignOrdersColumnTemplate;
            }

            return dojoString.substitute(template, {
                text: text,
                nrOfOrders: nrOfOrdersModel.amount
            });
        },

        _getRevenueValueHtml: function (revenueModel) {

            if (revenueModel.itemType !== MarketingUtils.type.campaign) {
                return "";
            }

            return dojoString.substitute(redeemedValueColumnTemplate, {
                redeemedValue: resources.redeemedvalue,
                redeemedValueAmount: revenueModel.revenue
            });
        },

        _getNameHtml: function (nameColumnModel) {
            var template = promotionNameColumnTemplate;

            if (nameColumnModel.itemType === MarketingUtils.type.campaign) {
                template = campaignNameColumnTemplate;
            }

            return dojoString.substitute(template, {
                name: shellMisc.htmlEncode(nameColumnModel.name),
                group: (!!nameColumnModel.group) ? resources.group[nameColumnModel.group] : resources.campaign,
                iconClass: TypeDescriptorManager.getValue(nameColumnModel.typeIdentifier, "iconClass")
            });
        }
    });
});