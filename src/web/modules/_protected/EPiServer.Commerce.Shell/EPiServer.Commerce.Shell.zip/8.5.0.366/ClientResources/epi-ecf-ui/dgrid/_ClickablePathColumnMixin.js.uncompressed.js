﻿define("epi-ecf-ui/dgrid/_ClickablePathColumnMixin", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/topic",
    "epi/shell/DestroyableByKey"
], function(
    declare,
    lang,
    aspect,
    topic,
    DestroyableByKey
){
    return declare([DestroyableByKey], {

        postCreate: function(){
            this.inherited(arguments);
            this._setupClickablePathColumn();
        },

        _setupClickablePathColumn: function(){
            this.ownByKey("pathColumnClick", this.on(".dgrid-cell.dgrid-column-path:click", lang.hitch(this, function(event){
                    var row = this.row(event);
                    topic.publish("/epi/shell/context/request", { uri: "epi.cms.contentdata:///" + row.data.target },{sender: this });
                }))
            );
            for (var columnName in this.columns){
                if (columnName === "path"){
                    this.columns[columnName].className = "epi-ecf-uiPathLink";
                }
            }
        }
    });
});