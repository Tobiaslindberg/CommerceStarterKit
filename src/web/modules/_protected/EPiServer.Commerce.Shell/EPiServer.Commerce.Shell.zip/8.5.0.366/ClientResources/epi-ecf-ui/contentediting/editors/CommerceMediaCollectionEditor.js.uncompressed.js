require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/CommerceMediaEditor.html':"﻿<div class=\"dijitInline\" style=\"width: 100%;\">    \r\n    <div data-dojo-attach-point=\"commandTargetNode\"></div>\r\n    <div data-dojo-attach-point=\"overlayDnd\">\r\n        <div data-dojo-attach-point=\"gridNode\"></div>\r\n    </div>\r\n    <div data-dojo-attach-point=\"dropContainer\" class=\"epi-content-area-actionscontainer\"></div>\r\n</div>\r\n"}});
﻿define("epi-ecf-ui/contentediting/editors/CommerceMediaCollectionEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom-class",
    "dojo/dom-style",
    "dojo/topic",

    // EPi Framework
    "epi/shell/widget/_FocusableMixin",
    "epi/shell/dnd/Target",
   

    // epi cms
    "epi-cms/contentediting/editors/CollectionEditor",
    "epi-cms/contentediting/editors/_TextWithActionLinksMixin",

    // epi commerce
    "epi-ecf-ui/contentediting/editors/model/CommerceMediaCollectionEditorModel",
    "epi-ecf-ui/component/CommerceMediaItemModel",

    // Resources
    "dojo/text!./templates/CommerceMediaEditor.html",
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.commercemediacollectioneditor"

],
function (
    //dojo
    declare,
    lang,
    aspect,
    domClass,
    domStyle,
    topic,

    // EPi Framework
    _FocusableMixin,
    Target,

    // epi cms
    CollectionEditor,
    _TextWithActionLinksMixin,

    // epi commerce
    CommerceMediaCollectionEditorModel,
    CommerceMediaItemModel,

    // Resources
    template,
    res
) {
    return declare([CollectionEditor, _TextWithActionLinksMixin, _FocusableMixin], {
        // module:
        //      epi-ecf-ui/contentediting/editors/commercemediacollectioneditor
        // summary:
        //      Editor widget for commerce media assets

        // _dndTarget: Function
        //      The dnd target area.
        _dndTarget: null,

        templateString: template,

        resources: res,

        gridOverlayClass: "epi-grid-dnd-overlay",

        _noDataMessage: '<span><span class="dijitReset dijitInline">' + res.nodatamessage + '</span></span>',

        // itemModelType: Function
        //      Item Model constructor.
        itemModelType: CommerceMediaItemModel,

        modelType: CommerceMediaCollectionEditorModel,

        // Set autofocus to false to prevent the validate the require fields when opening dialog. 
        dialogParams: { autofocus: false },

        _setupGrid: function () {
            // summary:
            //      Set up the grid.
            // tags:
            //      protected

            this.inherited(arguments);
            domClass.add(this.gridNode, "epi-plain-grid--margin-bottom epi-plain-grid--cell-borders");

            this._settingReadOnlyState();
        },

        postCreate: function () {
            // summary:
            //      Post create initialization.
            // description:
            //      Setup related components.
            // tags:
            //      protected

            this.inherited(arguments);

            this._dndTarget = new Target(this.dropContainer, {
                accept: this.allowedDndTypes,
                insertNodes: function () { }
            });

            this.own(aspect.after(this._dndTarget, "onDropData", lang.hitch(this, this.onDndDrop), true));

            domClass.add(this.domNode, "epi-media-collection");
            this.setupActionLinks(this.dropContainer);
        },

        _settingReadOnlyState: function () {
            if (this.readOnly) {
                // For dnd
                domStyle.set(this.dropContainer, "display", "none");
                domClass.remove(this.overlayDnd, this.gridOverlayClass);

                // For grid
                this.grid.set("selectionMode", "none");
                this.allowedDndTypes = [];
                this.gridSettings.dndDisabled = true;
                this.model.availableCommands = 0;
            }
        },

        _getDialogTitleText: function(existingItem){
            return !existingItem ? res.addlabel : res.editlabel;
        },

        getTemplateString: function () {
            // summary:
            //      The template string for drop area
            // tags:
            //      protected

            return {
                templateString: this.resources.drophere,
                actions: this.resources.actions
            };
        },

        executeAction: function (actionName) {
            // summary:
            //      Called when [items] link clicked
            // tags:
            //      public override

            topic.publish("/epi/layout/pinnable/tools/toggle", true);
        },

        _getGridDefinition: function () {
            // summary:
            //      Returns grid's columns definition.
            // tags:
            //      private

            var columns = this.generateColumns ?
                this.model.generateColumnsDefinition(this.excludedColumns) : // If auto generate is on, ask model to compute columns definition.
                this.includedColumns || {}; // Otherwise, use configured ones.

            if (this.readOnly)
            {
                for (var columnName in columns) {
                    lang.setObject("sortable", false, columns[columnName]);
                }
            }

            return this.model.generateFormatters(columns);
        },

        _setupDnD: function () {
            // summary:
            //      Set up the dnd on the grid.
            // tags:
            //      private
            this.inherited(arguments);
            var dndSource = this.grid.dndSource;

            this.own(aspect.after(dndSource, "onDndStart", lang.hitch(this, function (source, nodes, copy) {
                var accepted = dndSource.accept && dndSource.checkAcceptance(source, nodes);
                domClass[accepted ? "add" : "remove"](this.overlayDnd, this.gridOverlayClass);
            }), true));
        }
    });
});