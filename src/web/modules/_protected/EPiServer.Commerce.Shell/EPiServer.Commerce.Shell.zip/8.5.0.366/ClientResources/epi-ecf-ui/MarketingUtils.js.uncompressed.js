define("epi-ecf-ui/MarketingUtils", [
],

function (
) {
    var marketingUtils = {
        // summary:
        //    This class contains utilities for working with marketing objects
        //    (campaigns, promotions)
        // tags:
        //    public static
        

        // type: Object
        //      Types used on marketing objects
        type : {
            // Note: These should match  EPiServer.Commerce.Shell.Rest.Models.CampaignItemType
            notSet: 0,
            promotion: 1,
            campaign : 2
        },

        // status: Object
        //      Statuses used on marketing objects 
        status : {
            // Note: These should match EPiServer.Commerce.Shell.Rest.Models.CampaignItemStatus
            notSet: 0,
            active: 1,
            pending : 2,
            expired: 3,
            suspended: 4,
            inactive: 5,
            deleted: 6
        }    
    };

    return marketingUtils;
});