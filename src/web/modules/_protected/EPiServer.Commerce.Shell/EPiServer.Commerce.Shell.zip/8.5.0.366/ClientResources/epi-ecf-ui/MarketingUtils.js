//>>built
define("epi-ecf-ui/MarketingUtils",[],function(){var _1={type:{notSet:0,promotion:1,campaign:2},status:{notSet:0,active:1,pending:2,expired:3,suspended:4,inactive:5,deleted:6}};return _1;});