require({cache:{
'url:epi-ecf-ui/widget/templates/CampaignItemList.html':"﻿<div>\n    <div class=\"epi-campaignHeading\">\n        <div class=\"epi-iconPrice epi-icon--medium epi-icon--inverted dijitInline\"></div>\n        <div class=\"epi-campaignDetails dijitInline\">\n            <h2 data-dojo-attach-point=\"campaignNameNode\"></h2>\n            <span data-dojo-attach-point=\"campaignDescriptionNode\"></span>\n        </div>\n    </div>\n    <div class=\"epi-campaignList\" data-dojo-attach-point=\"gridNode\"></div>\n</div>\n"}});
﻿define("epi-ecf-ui/widget/CampaignItemList", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom-class",
    "dojo/when",
// dijit
    "dijit/_TemplatedMixin",
// epi
    "epi-cms/widget/_GridWidgetBase",
// commerce
    "./viewmodel/CampaignItemListModel",
    "dojo/text!./templates/CampaignItemList.html",
// resources
    "epi/i18n!epi/nls/commerce.widget.campaignitemlist"
],
function (
// dojo
    declare,
    lang,
    aspect,
    domClass,
    when,
//dijit
    _TemplatedMixin,
// epi
    _GridWidgetBase,
// commerce
    CampaignItemListModel,
    templateString,
// resources
    resources
) {
    return declare([_GridWidgetBase], {

        storeKeyName: "epi.commerce.campaignitem",

        postMixInProperties: function () {
            this.inherited(arguments);
            this.model = new CampaignItemListModel();
        },

        buildRendering: function () {
            // summary:
            //		Construct the UI for this widget with this.domNode initialized as a dgrid.
            // tags:
            //		protected

            this.inherited(arguments);

            this._modifyStoreToHandleDgridTree();

            var gridSettings = lang.mixin(this.defaultGridMixin, {
                className: "epi-card-grid",
                columns: this.model.createGridColumns(),
                store: this.store,
                selectionMode: "none",
                dndDisabled: true,
                showHeader: false,
                noDataMessage: resources.emptycampaign,
                query: {query: "getchildren"}, // we don't specify a reference id to get all campaigns
                renderArray: function(){
                    return when(this.inherited(arguments), lang.hitch(this, function(trs){
                        //After calling the inherited renderArray function we clear the noDataNode.
                        //This forces the grid to create a new node every time a campaign does not have any promotion.
                        this.noDataNode = null;
                        return trs;
                    }));
                }
            });

            this.grid = new this._gridClass(gridSettings, this.domNode);
        },

        startup: function() {
            this.inherited(arguments);

            this.own(aspect.around(this.grid, "renderRow", lang.hitch(this, this._aroundRenderRow)));
        },

        _aroundRenderRow: function (original) {
            // summary:
            //      Called 'around' the renderRow method in order to add a class which indicates the state of the row
            // tags:
            //      private

            return lang.hitch(this, function (item) {
                // Call original method
                var row = original.apply(this.grid, arguments);

                domClass.add(row, this.model.getItemClass(item));
                domClass.add(row, this.model.getItemStatusClass(item));

                return row;
            });
        },

        _modifyStoreToHandleDgridTree: function(){
            // summary:
            //      getChildren and mayHaveChildren are needed on the store
            //      for dgrids tree module to work.
            // tags:
            //      private

            this.store = lang.mixin(this.store, {
                getChildren: function (parent, options) {
                    return this.query({query: "getchildren", referenceId: parent.internalId}, options);
                },
                mayHaveChildren: function (parent) {
                    //this is only called by dgrids tree module and therefore we only want to do it on entries
                    return parent.mayHaveChildren;
                }
            });
        },

        contextChanged: function (context, callerData) {
            /// only call onContextChanged if context type is "epi.commerce.campaign"

            this.inherited(arguments);

            if (context.type !== "epi.commerce.campaign") {
                return;
            }

            if (!callerData || callerData.sender !== this) {
                this.onContextChanged(context);
            }
        },

        _onChangeContext: function (uri) {
            // TODO: Remove this override when we support navigation to specific promotions.
        }
    });
});